package com.example.androidhometask2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SearchFragment extends Fragment {
    public static SearchFragment newInstance() {

        Bundle args = new Bundle();

        SearchFragment fragment = new SearchFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private EditText mEditText;
    private Button mButton;

    private void onButtonClick(View view) {
        if (TextUtils.isEmpty(mEditText.getText())) {
            Toast.makeText(getActivity(), "Введите строку для поиска", Toast.LENGTH_LONG).show();
            return;
        }

        SharedPreferences preferences = getActivity().getSharedPreferences(
                getString(R.string.shared_preferences_search_system), Context.MODE_PRIVATE);

        String formatString = "";
        switch (preferences.getInt(getString(R.string.shared_preference_radio_button_id), R.id.rbGoogle)) {
            case R.id.rbGoogle:
                formatString = getString(R.string.format_string_google);
                break;

            case R.id.rbYandex:
                formatString = getString(R.string.format_string_yandex);
                break;

            case R.id.rbBing:
                formatString = getString(R.string.format_string_bing);
                break;
        }

        Uri uri = Uri.parse(String.format(formatString,
                Uri.encode(mEditText.getText().toString())));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.search_layout, container, false);
        mButton = view.findViewById(R.id.buttonSearch);
        mEditText = view.findViewById(R.id.etSearch);
        mButton.setOnClickListener(this::onButtonClick);

        return view;
    }
}
