package com.example.zadanie2;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Search.OnFragmentInteractionListener, Settings.OnFragmentInteractionListener, MainFragment.OnFragmentInteractionListener {
    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    Search searchFrag;
    Settings settingsFrag;
    MainFragment mainFrag;
    FragmentManager fragMan;

    static SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("com.example.zadanie2", Context.MODE_PRIVATE);

        searchFrag = new Search();
        settingsFrag = new Settings();
        mainFrag = new MainFragment();

        fragMan = getSupportFragmentManager();
        fragMan.beginTransaction().add(R.id.frameLayout, mainFrag).commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.exit:
                Toast.makeText(MainActivity.this, "Exit", Toast.LENGTH_SHORT).show();
                finish();
                return true;
            case R.id.search:
                Toast.makeText(MainActivity.this, "Search", Toast.LENGTH_SHORT).show();
                fragMan.beginTransaction().replace(R.id.frameLayout, searchFrag).addToBackStack(null).commit();
                return true;
            case R.id.settings:
                Toast.makeText(MainActivity.this, "Settings", Toast.LENGTH_SHORT).show();
                fragMan.beginTransaction().replace(R.id.frameLayout, settingsFrag).addToBackStack(null).commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
