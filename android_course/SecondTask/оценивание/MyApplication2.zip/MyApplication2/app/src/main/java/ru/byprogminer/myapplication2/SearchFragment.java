package ru.byprogminer.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class SearchFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        final View ret = inflater.inflate(R.layout.fragment_search, container, false);

        Searcher searcher = Searcher.DEFAULT;
        final Bundle args = getArguments();
        if (args != null) {
            final String searcherName = args.getString("searcher");

            if (searcherName != null) {
                searcher = Searcher.valueOf(searcherName);
            }
        }

        final String url = searcher.getUrl();
        ret.findViewById(R.id.search_button).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditText searchField = ret.findViewById(R.id.search_field);

                searchField.setEnabled(false);
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url + searchField.getText().toString())));
                searchField.setEnabled(true);
            }
        });

        return ret;
    }
}
