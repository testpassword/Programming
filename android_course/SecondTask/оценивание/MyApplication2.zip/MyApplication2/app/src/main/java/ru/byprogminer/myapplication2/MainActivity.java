package ru.byprogminer.myapplication2;

import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SettingsFragment.SettingsListener {

    private FragmentManager fragmentManager;

    private BlankFragment fragmentStart;
    private SearchFragment fragmentSearch;
    private SettingsFragment fragmentSettings;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferences = getSharedPreferences("main", MODE_PRIVATE);
        fragmentManager = getSupportFragmentManager();

        fragmentStart = new BlankFragment();
        fragmentSearch = new SearchFragment();
        fragmentSettings = new SettingsFragment();
        fragmentSettings.setSettingsListener(this);

        switchToFragment(fragmentStart);
    }

    public void onClickSearch(MenuItem item) {
        onClick(item);

        final Bundle searchArgs = new Bundle();
        searchArgs.putString("searcher", preferences.getString("searcher", Searcher.DEFAULT.name()));
        fragmentSearch.setArguments(searchArgs);
        switchToFragment(fragmentSearch);
    }

    public void onClickSettings(MenuItem item) {
        onClick(item);

        final Bundle settingsArgs = new Bundle();
        settingsArgs.putString("searcher", preferences.getString("searcher", Searcher.DEFAULT.name()));
        fragmentSettings.setArguments(settingsArgs);
        switchToFragment(fragmentSettings);
    }

    public void onClickExit(MenuItem item) {
        onClick(item);
        finish();
    }

    private void onClick(MenuItem item) {
        Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
    }

    private void switchToFragment(Fragment fragment) {
        if (fragment.isVisible()) {
            return;
        }

        fragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null).commit();
    }

    @Override
    public void onSearcherChanged(Searcher searcher) {
        preferences.edit()
                .putString("searcher", searcher.name())
                .apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (fragmentStart.isVisible()) {
            finish();
        }


        final Bundle args = new Bundle();
        args.putString("searcher", preferences.getString("searcher", Searcher.DEFAULT.name()));
        fragmentSettings.setArguments(args);
        fragmentSearch.setArguments(args);

        super.onBackPressed();
    }
}
