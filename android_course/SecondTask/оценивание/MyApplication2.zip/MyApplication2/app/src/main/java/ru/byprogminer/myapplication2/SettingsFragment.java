package ru.byprogminer.myapplication2;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public class SettingsFragment extends Fragment {

    interface SettingsListener {

        void onSearcherChanged(Searcher searcher);
    }

    private static final Map<Searcher, Integer> SEARCHER_BUTTONS;

    private SettingsListener listener = null;

    static {
        final Map<Searcher, Integer> searcherButtons = new EnumMap<>(Searcher.class);

        searcherButtons.put(Searcher.GOOGLE, R.id.radio_google);
        searcherButtons.put(Searcher.YANDEX, R.id.radio_yandex);
        searcherButtons.put(Searcher.BING, R.id.radio_bing);

        SEARCHER_BUTTONS = Collections.unmodifiableMap(searcherButtons);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View ret = inflater.inflate(R.layout.fragment_settings, container, false);

        final Bundle args = getArguments();
        if (args != null) {
            final String searcherName = args.getString("searcher");

            if (searcherName != null) {
                setSearcher(Searcher.valueOf(searcherName), ret);
            }
        }

        final RadioGroup radioGroup = ret.findViewById(R.id.settings_radios);
        if (radioGroup != null) {
            if (radioGroup.getCheckedRadioButtonId() == -1) {
                setSearcher(Searcher.DEFAULT, ret);
            }

            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int id) {
                    if (listener != null) {
                        for (Map.Entry<Searcher, Integer> buttonSearcher: SEARCHER_BUTTONS.entrySet()) {
                            if (buttonSearcher.getValue() == id) {
                                listener.onSearcherChanged(buttonSearcher.getKey());
                                break;
                            }
                        }
                    }
                }
            });
        }

        return ret;
    }

    private void setSearcher(Searcher searcher, View view) {
        if (view == null) {
            return;
        }

        final RadioGroup group = view.findViewById(R.id.settings_radios);
        if (group == null) {
            return;
        }

        group.check(SEARCHER_BUTTONS.get(searcher));
    }

    public void setSettingsListener(SettingsListener listener) {
        this.listener = listener;
    }
}
