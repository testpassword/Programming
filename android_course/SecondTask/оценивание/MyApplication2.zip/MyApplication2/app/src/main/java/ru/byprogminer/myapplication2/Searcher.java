package ru.byprogminer.myapplication2;

enum Searcher {

    GOOGLE("https://www.google.com/search?q="),
    YANDEX("https://yandex.ru/search/?text="),
    BING("https://www.bing.com/search?q=");

    public static final Searcher DEFAULT = GOOGLE;
    private String url;

    Searcher(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
