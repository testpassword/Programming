package org.stepik.stepicapp2;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class FragmentSearch extends Fragment {

    private SharedPreferencesHelper helper;
    private EditText editText;
    private Button buttonSerch;
    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!TextUtils.isEmpty(editText.getText())) {
                String query = editText.getText().toString();
                Uri uri = Uri.parse(helper.getSearchSite() + query);
                Intent searchIntent = new Intent(Intent.ACTION_VIEW, uri);
                getActivity().startActivity(searchIntent);
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fr_search, container, false);
        editText = view.findViewById(R.id.fr_search_et);
        buttonSerch = view.findViewById(R.id.fr_search_btn);
        buttonSerch.setOnClickListener(listener);
        helper = new SharedPreferencesHelper(getActivity());
        return view;
    }

    public static FragmentSearch newInstance() {
        return new FragmentSearch();
    }

}
