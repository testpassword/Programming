package org.stepik.stepicapp2;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesHelper {

    public static final String SHARED_PREF_NAME = "SHARED_PREF_NAME";
    public static final String SEARCH_KEY = "SEARCH_KEY";
    private SharedPreferences preferences;

    public SharedPreferencesHelper(Context context) {
        preferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveSearchSite(String site) {
        preferences.edit().putString(SEARCH_KEY, site).apply();
    }

    public String getSearchSite() {
        return preferences.getString(SEARCH_KEY, "https://www.google.com/search?q=");
    }
}
