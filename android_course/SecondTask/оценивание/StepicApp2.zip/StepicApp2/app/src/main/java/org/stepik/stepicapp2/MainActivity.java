package org.stepik.stepicapp2;

import android.support.v4.app.Fragment;

public class MainActivity extends AbstractActivity {


    @Override
    protected Fragment getFragment() {
        return DefaultFragment.newInstance();
    }
}
