package org.stepik.stepicapp2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

public class FragmentSettings extends Fragment {

    private SharedPreferencesHelper preferencesHelper;
    private RadioGroup radioGroup;

    /*
     * Я с Украины. У нас Яндекс заблокирован, поэтому я не уверен, работает ли поиск в Яндексе :(
     */
    private RadioGroup.OnCheckedChangeListener onCheckedChangeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch (checkedId) {
                case R.id.radio_google:
                    preferencesHelper.saveSearchSite("https://www.google.com/search?q=");
                    break;
                case R.id.radio_yandex:
                    preferencesHelper.saveSearchSite("https://www.yandex.ru/search?text=");
                    break;
                case R.id.radio_bing:
                    preferencesHelper.saveSearchSite("https://www.bing.com/search?q=");
                    break;
                default:
                    break;
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fr_settings, container, false);
        radioGroup = view.findViewById(R.id.radio_group);
        radioGroup.setOnCheckedChangeListener(onCheckedChangeListener);
        preferencesHelper = new SharedPreferencesHelper(getActivity());
        return view;
    }

    public static FragmentSettings newInstance() {
        return new FragmentSettings();
    }
}
