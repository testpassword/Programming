package ru.ifmo.se.pokemon;

public enum Status {
    NORMAL, BURN, FREEZE, POISON, SLEEP, PARALYZE
}
